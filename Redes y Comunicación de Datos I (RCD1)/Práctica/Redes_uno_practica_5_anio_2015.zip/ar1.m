function varargout = ar1(varargin)
% AR1 Application M-file for ar1.fig
%    FIG = AR1 launch ar1 GUI.
%    AR1('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 04-Dec-2001 22:18:16
global codif;
global menu;

if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'new');

	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);

	if nargout > 0
		varargout{1} = fig;
	end

    setlogo(handles.logodac);

    menu.nrz=1;
    menu.ttl=2;
    menu.bifase=3;
    menu.bifasedif=4;
    menu.bipolar=5;
    menu.b8zs=6;
    menu.multinivel=7;
    menu.ask=8;
    menu.fsk=9;
    menu.psk=10;
    menu.qpsk=11;
    codif.atenuacionon=get(handles.atenuacionon,'Value');
    codif.noiseon=get(handles.noiseon,'Value');
    codif.atenuacion=str2num(get(handles.atenuacion,'String'));
    codif.longitud=str2num(get(handles.longitud,'String'));
    codif.vt=str2num(get(handles.vt,'String'));
    codif.tb=1/codif.vt;
    codif.cod=get(handles.codificacion,'Value');
    codif.msg=get(handles.edit1,'String');
    codif.b=length(codif.msg);
    codif.Afuente=1;
    codif.Acanal=str2num(get(handles.acanal,'String'));
    codif.ymin=-.85*codif.Acanal;
    codif.ymax=.85*codif.Acanal;
    % Ruido en el canal
    codif.noise=str2num(get(handles.noise,'String'));
    codif.Anoise=codif.Acanal/(10^(codif.noise/20));
    % Frecuencia portadora
    codif.Fp=str2num(get(handles.fp,'String'));
    % Desplazamiento desde Fp
    codif.dF=codif.Fp/6;
    % Amplitud portadora
    codif.Ap=1;
    % Cambio de fase
    codif.Pp=pi;
    % Frecuencia de muestreo
    codif.muestras=str2num(get(handles.freqm,'String'));
    % Frecuencias de corte
    codif.low=str2num(get(handles.low,'String'));
    codif.high=str2num(get(handles.high,'String'));
%    codif.xmin=-codif.tb;
    codif.xmin=0;
    codif.xmax=codif.tb*(codif.b+1);
    % Zoom inicial del medio
    codif.zoom=1;
    update_all(handles);

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
		disp(lasterr);
	end

end


%| ABOUT CALLBACKS:
%| GUIDE automatically appends subfunction prototypes to this file, and 
%| sets objects' callback properties to call them through the FEVAL 
%| switchyard above. This comment describes that mechanism.
%|
%| Each callback subfunction declaration has the following form:
%| <SUBFUNCTION_NAME>(H, EVENTDATA, HANDLES, VARARGIN)
%|
%| The subfunction name is composed using the object's Tag and the 
%| callback type separated by '_', e.g. 'slider2_Callback',
%| 'figure1_CloseRequestFcn', 'axis1_ButtondownFcn'.
%|
%| H is the callback object's handle (obtained using GCBO).
%|
%| EVENTDATA is empty, but reserved for future use.
%|
%| HANDLES is a structure containing handles of components in GUI using
%| tags as fieldnames, e.g. handles.figure1, handles.slider2. This
%| structure is created at GUI startup using GUIHANDLES and stored in
%| the figure's application data using GUIDATA. A copy of the structure
%| is passed to each callback.  You can store additional information in
%| this structure at GUI startup, and you can change the structure
%| during callbacks.  Call guidata(h, handles) after changing your
%| copy to replace the stored original so that subsequent callbacks see
%| the updates. Type "help guihandles" and "help guidata" for more
%| information.
%|
%| VARARGIN contains any extra arguments you have passed to the
%| callback. Specify the extra arguments by editing the callback
%| property in the inspector. By default, GUIDE sets the property to:
%| <MFILENAME>('<SUBFUNCTION_NAME>', gcbo, [], guidata(gcbo))
%| Add any extra arguments after the last argument, before the final
%| closing parenthesis.

% --------------------------------------------------------------------
function varargout = vt_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.vt.
global codif;
codif.vt=str2num(get(h,'String'));
codif.tb=1/codif.vt;
%codif.xmin=-codif.tb;
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = fm_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.freqm.
global codif;
codif.muestras=str2num(get(h,'String'));
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = fp_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.fp.
global codif;
codif.Fp=str2num(get(h,'String'));
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = acanal_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.acanal.
global codif;
codif.Acanal=str2num(get(h,'String'));
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = noise_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.noise.
global codif;
codif.noise=str2num(get(h,'String'));
codif.Anoise=codif.Acanal/(10^(codif.noise/20));
codif.noiseon=1;
set(handles.noiseon,'Value',1);
% Actualiza pantalla
update_all(handles);


% Zoom del espectro
% --------------------------------------------------------------------
function varargout = zoom_Callback(h, eventdata, handles, z)
% Stub for Callback of the uicontrol handles.selespectro.
global codif;
  x=get(handles.axes3, 'XLim');
  if (z==-1) x(2)=x(2)*2; codif.zoom=codif.zoom*2; end
  if (z==1) x(2)=x(2)/2; codif.zoom=codif.zoom/2; end
  set(handles.axes3,'XLim',[x(1) x(2)]);


% Pan del espectro
% --------------------------------------------------------------------
function varargout = pan_Callback(h, eventdata, handles, p)
% Stub for Callback of the uicontrol handles.pan.
global codif;
  x=get(handles.axes3, 'XLim');
  switch p
  case -1
    x(1)=x(1)-codif.nm/(50/codif.zoom);
    x(2)=x(2)-codif.nm/(50/codif.zoom);
  case 1
    x(1)=x(1)+codif.nm/(50/codif.zoom);
    x(2)=x(2)+codif.nm/(50/codif.zoom);
  end
  set(handles.axes3,'XLim',[x(1) x(2)]);


% --------------------------------------------------------------------
function varargout = low_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.low.
global codif;
l=str2num(get(h,'String'));
if (l>=codif.high)
    set(h,'String',num2str(codif.low));
    return;
else
    codif.low=l;
end
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = atenuacion_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.atenuacion.
global codif;
codif.atenuacion=str2num(get(h,'String'));
codif.atenuacionon=1;
set(handles.atenuacionon,'Value',1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = longitud_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.longitud.
global codif;
l=str2num(get(h,'String'));
if (l<0)
    set(h,'String',num2str(codif.longitud));
    return;
else
    codif.longitud=l;
end
codif.atenuacionon=1;
set(handles.atenuacionon,'Value',1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = high_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.high.
global codif;
hi=str2num(get(h,'String'));
if (hi<=codif.low)
    set(h,'String',num2str(codif.high));
    return;
else
    codif.high=hi;
end
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = edit1_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
msg=get(h,'String');
for i=1:length(msg)
    if ((msg(i)~='0') & (msg(i)~='1'))
        disp('Cadena erronea');
        set(h,'String',codif.msg);
        return;
    end
end
codif.msg=msg;
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = codificacion_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.codificacion.
global codif menu;
codif.cod=get(h,'Value');
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = noiseon_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.noiseon.
global codif;
codif.noiseon=get(h,'Value');
% Actualiza pantalla
update_all(handles);



% --------------------------------------------------------------------
function varargout = atenuacionon_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.atenuacionon.
global codif;
codif.atenuacionon=get(h,'Value');
% Actualiza pantalla
update_all(handles);

% --------------------------------------------------------------------
function varargout = mensajes_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.atenuacionon.
global codif;
s=get(h,'Value');
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = mensaje_00(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='0000000000000000';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = mensaje_11(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='1111111111111111';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = mensaje_10(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='1010101010101010';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = mensaje_01(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='0101010101010101';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = mensaje_010(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='0000100000010000';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);


% --------------------------------------------------------------------
function varargout = mensaje_101(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='1111011111101111';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);



% --------------------------------------------------------------------
function varargout = mensaje_0011(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='0011001100110011';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);



% --------------------------------------------------------------------
function varargout = mensaje_000111(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='0001110001110001';
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);



% --------------------------------------------------------------------
function varargout = mensaje_rand(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;
codif.msg='';
m=floor(2*rand(1,32));
for i=1:length(m)
  codif.msg(i)='0'+m(i);
%  if(m(i)==0) codif.msg(i)='0';
%  else codif.msg(i)='1';
%  end
end
set(handles.edit1,'String',codif.msg);
codif.b=length(codif.msg);
codif.xmax=codif.tb*(codif.b+1);
% Actualiza pantalla
update_all(handles);

% --------------------------------------------------------------------
function varargout = mensaje_repetir(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
global codif;

l=32;
ntest=20; % numero de veces que se repite
nerr=0;
for i=1:ntest
  codif.msg='';
  m=floor(2*rand(1,l));
  for i=1:length(m)
    codif.msg(i)='0'+m(i);
  end
  set(handles.edit1,'String',codif.msg);
  codif.b=length(codif.msg);
  codif.xmax=codif.tb*(codif.b+1);
  % Actualiza pantalla
  nerr=nerr+update_all(handles);
  pause(0.1);
end
pe=nerr/(ntest*l);
set(handles.pe,'String',sprintf('%.2e',pe));



% --------------------------------------------------------------------
%               Funciones de manipulacion de codificaciones
% --------------------------------------------------------------------


% Esta funcion calcula las codificaciones de fuente y canal y las
%  muestra como graficas
% --------------------------------------------------------------------
function [nerr] = update_all(handles)
global codif;

% Desplazamiento desde Fp -- Esto no estaba en la version original
codif.dF=codif.Fp/6;

codif.xmax=codif.tb*(codif.b+1);

[codif.binmsg,codif.fuentex,codif.fuentey]=codif_fuente(codif);
codif.fm=codif.muestras/(codif.tb*length(codif.binmsg));
[codif.canalx,codif.canaly]=codif_canal;

plot_codif(handles.axes1, codif.fuentex, codif.fuentey, codif.xmin, codif.xmax, -0.5*codif.Afuente, 1.5*codif.Afuente, codif.tb, 0, codif.Acanal);

if (codif.cod==2)
  plot_codif(handles.axes2, codif.canalx, codif.canaly, codif.xmin, codif.xmax, codif.ymin, codif.ymax, codif.tb, -codif.Acanal, codif.Acanal);
else
  plot_codif(handles.axes2, codif.canalx, codif.canaly, codif.xmin, codif.xmax, codif.ymin, codif.ymax, codif.tb, -codif.Acanal/2, codif.Acanal/2);
end

[codif.freqs,codif.espectro,codif.power]=espectro(codif);
plot_spectrum(handles.axes3, codif.freqs, codif.power(1:length(codif.freqs)), 0, max(codif.freqs)/2, 0, max(codif.power),codif.low,codif.high);

r=recv(codif.espectro,codif.fm,codif.low,codif.high);
codif.receivedy=ifft(r);
resta_atenuacion;
if (codif.noiseon) suma_ruido; end

%l1=codif.low; h1=codif.Fp;
%l2=codif.Fp; h2=codif.high;
%ec1=recv(codif.espectro,codif.fm,l1,h1);
%ec2=recv(codif.espectro,codif.fm,l2,h2);
%c1=ifft(ec1);
%c2=ifft(ec2);
%plot_codif(handles.axes4, codif.canalx, c2, codif.xmin, codif.xmax, codif.ymin, codif.ymax, codif.tb, -codif.Acanal/2, codif.Acanal/2);

if (codif.cod==2)
  plot_codif(handles.axes4, codif.canalx, real(codif.receivedy), codif.xmin, codif.xmax, codif.ymin, codif.ymax, codif.tb, -codif.Acanal/2, codif.Acanal/2);
else
  plot_codif(handles.axes4, codif.canalx, real(codif.receivedy), codif.xmin, codif.xmax, codif.ymin, codif.ymax, codif.tb, -codif.Acanal/2, codif.Acanal/2);
end

codif.rcbinmsg=decodif_canal;
nerr=plot_msg(handles.recvmsg,handles.errmsg, codif.binmsg, codif.rcbinmsg);


% Esta funcion imprime el mensaje recibido comparado con el enviado
% --------------------------------------------------------------------
function [nerr] = plot_msg(textbox1,textbox2, binmsg, rcbinmsg)
  nerr=0;
  for i=1:length(binmsg)
      if (binmsg(i)==rcbinmsg(i))
          switch rcbinmsg(i)
          case 0
              rcmsg(i)='0'; ercmsg(i)=' ';
          case 1
              rcmsg(i)='1'; ercmsg(i)=' ';
          end
      elseif (rcbinmsg(i)==2) rcmsg(i)='?';  ercmsg(i)='?'; nerr=nerr+1;
      else
          switch rcbinmsg(i)
          case 0
              rcmsg(i)='0'; ercmsg(i)='E'; nerr=nerr+1;
          case 1
              rcmsg(i)='1'; ercmsg(i)='E'; nerr=nerr+1;
          end
      end
  end
  set(textbox1,'String',rcmsg);
  set(textbox2,'String',ercmsg);

% Esta funcion imprime la codificacion dada en la grafica indicada
% --------------------------------------------------------------------
function plot_codif(ax, x, y, xmin, xmax, ymin, ymax, tb, Amin, Amax)
  axes(ax);
  set(gcf,'CurrentAxes',ax);
  cla reset;
  n=floor((xmax-xmin)/tb);
  for i=0:n-1
    line([i*tb, i*tb], [ymin, ymax], 'Color',[0 .75 .75],'LineStyle','-');
  end
  hold on;
  plot (x,y);
  hold off;
  set(ax,'XGrid','off','YGrid','on');
  set(ax,'XTick',[0:4*tb:xmax]);
  set(ax,'XLim',[xmin xmax]);
  set(ax,'YLim',[ymin ymax]);
  if (Amin==0) set(ax,'YTick',[0 Amax]);
  else set(ax,'YTick',[Amin 0 Amax]);
  end


% Esta funcion imprime el espectro
% --------------------------------------------------------------------
function plot_spectrum(ax, x, y, xmin, xmax, ymin, ymax, low, high)
  global codif;
  axes(ax);
  set(gcf,'CurrentAxes',ax);
  set(gca,'XGrid','off');
  cla reset;
  hold on;
  if (ymax-ymin==0) ymax=1; end
  rectangle('Position',[low,ymin,high-low,ymax-ymin],'EdgeColor',[1 0 0],'FaceColor',[.9 .9 .9]);
  line([low, low], [ymin, ymax], 'Color',[1 0 0]);
  line([high, high], [ymin, ymax], 'Color',[1 0 0]);
  plot (x,y);
  set(ax,'XLim',[xmin xmax*codif.zoom]);
  set(ax,'YLim',[ymin ymax]);



% --------------------------------------------------------------------
%               Funciones de generacion de codificaciones  
% --------------------------------------------------------------------


% Esta funcion genera dos arrays con la codificacion de fuente para
%   la velocidad y el mensaje indicados.
% --------------------------------------------------------------------
% MODIFICADA 10/10/2003, S. Diaz
function [f,espectro,power]=espectro(codif)
  espectro=fft(codif.canaly);
  n=length(espectro);
  % la energia de la se�al puede verse evaluando:
  % sum(codif.canaly.*codif.canaly)/n
  power=sqrt(espectro.*conj(espectro))/n; % en realidad es la amplitud, no la potencia
  power((1:n/2-1) +1)=power((1:n/2-1) +1)+power((n-1:-1:n/2+1) +1);
  f=codif.fm*(0:n/2)/n;


% Esta funcion filtra el espectro recibido
% --------------------------------------------------------------------
% MODIFICADA 09/10/2003, S. Diaz
function [r]=recv(espectro,fm,low,high)
  l=length(espectro);
  r=espectro;
  % Caso f=0
  i=0;
  f=fm*i/l;
  if (f<low | f>high)
    r(i +1)=0;
  end
  % Caso general
  for i=1:l/2 
    f=fm*i/l;
    if (f<low | f>high)
      r(i +1)=0;
      r(l-i +1)=0;
    end
  end

  
% Esta funcion genera dos arrays con la codificacion de fuente para
%   la velocidad y el mensaje indicados.
% --------------------------------------------------------------------
function [binmsg,fuentex,fuentey]=codif_fuente(codif)
  for i=1:length(codif.msg)
      switch codif.msg(i)
      case '0'
          binmsg(i)=0;
      case '1'
          binmsg(i)=codif.Afuente;
      end
      fuentex(2*i-1)=(i-1)*codif.tb;
      fuentex(2*i)=i*codif.tb;
      fuentey(2*i-1)=binmsg(i);
      fuentey(2*i)=binmsg(i);
  end


% Esta funcion suma ruido a la codificacion de canal recibida
% --------------------------------------------------------------------
function suma_ruido()
  global codif;
  codif.receivedy=codif.receivedy + (codif.Anoise*rand(1,length(codif.receivedy))-codif.Anoise/2);

% Esta funcion atenua la se�al en funcion de la distancia
% --------------------------------------------------------------------
function resta_atenuacion()
  global codif;
  if (codif.atenuacionon)
    A=1/(10^((codif.longitud*codif.atenuacion)/20));
    codif.receivedy=codif.receivedy * A;
  end

% Esta funcion genera dos arrays con la senyal correspondiente a la codificacion
%   indicada para la velocidad y el mensaje indicados.
% --------------------------------------------------------------------
function [canalx,canaly]=codif_canal()
  global codif menu;
  % Numero de muestras a tomar
  codif.nm=codif.b*codif.tb*codif.fm;
  % Muestras por bit
  n=floor(codif.nm/codif.b);
  codif.ymin=-.85*codif.Acanal;
  codif.ymax=.85*codif.Acanal;
  
  switch codif.cod
    % NRZ    
    case menu.nrz
      for i=1:codif.b
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          canaly(n*(i-1)+j)=codif.binmsg(i)*codif.Acanal-codif.Acanal/2;
        end
      end
    % TTL    
    case menu.ttl
      codif.ymin=-1.7*codif.Acanal;
      codif.ymax=1.7*codif.Acanal;
      for i=1:codif.b
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          canaly(n*(i-1)+j)=codif.binmsg(i)*codif.Acanal;
        end
      end
    % Manchester
    case menu.bifase
      for i=1:codif.b
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          if (codif.binmsg(i)==0) v=-.5;
          else v=.5;
          end
          if (j<n/2)
              canaly(n*(i-1)+j)=-v*codif.Acanal;
          else
              canaly(n*(i-1)+j)= v*codif.Acanal;
          end
        end
      end
    % Manchester diferencial
    case menu.bifasedif
      m(1)=0;
      for i=1:codif.b
          if (codif.binmsg(i)==0) m(i+1)=m(i);
          else m(i+1)=~m(i);
          end
      end
      for i=1:codif.b+1
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          if (m(i)==0) v=-.5;
          else v=.5;
          end
          if (j<n/2)
              canaly(n*(i-1)+j)=-v*codif.Acanal;
          else
              canaly(n*(i-1)+j)= v*codif.Acanal;
          end
        end
      end
    % Bipolar
    case menu.bipolar
      s=1;     
      for i=1:codif.b
        if (codif.binmsg(i)==0) v=0;
        else v=.5*s; s=-s;
        end
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          canaly(n*(i-1)+j)=v*codif.Acanal;
        end
      end
    % B8ZS
    case menu.b8zs
      s=1; i=1;
      while (i<=codif.b)
          if (codif.binmsg(i)==1) m(i)=s; s=-s; i=i+1;
          else
              % Busca serie de 8 ceros
              j=0;
              while (i+j<=codif.b & j<8 & codif.binmsg(i+j)==0)
                  j=j+1;
              end
              if (j==8)
                  % Sustituye una serie de 8 ceros
                  m(i:i+2)=0;
                  m(i+3)=-s;
                  m(i+4)=s;
                  m(i+5)=0;
                  m(i+6)=s;
                  m(i+7)=-s;
              else
                  for k=0:j-1
                      m(i+k)=0;
                  end
              end
              i=i+j;
          end
      end
      
      for i=1:codif.b
        if (m(i)==0) v=0;
        elseif (m(i)==1) v=0.5;
        else v=-0.5;
        end
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          canaly(n*(i-1)+j)=v*codif.Acanal;
        end
      end
    % Multinivel    
    case menu.multinivel
      % Numero de muestras a tomar
      codif.nm=codif.b*codif.tb*codif.fm;
      % Muestras por bit
      n=floor(codif.nm/(codif.b/2));

      l=codif.b;
      if (mod(l,2)==1) l=l+1; codif.binmsg(l)=0; end
      for i=1:2:codif.b
        if (codif.binmsg(i)==0 & codif.binmsg(i+1)==0) a=0;
        elseif (codif.binmsg(i)==0 & codif.binmsg(i+1)==1) a=codif.Acanal*1/3;
        elseif (codif.binmsg(i)==1 & codif.binmsg(i+1)==0) a=codif.Acanal*2/3;
        elseif (codif.binmsg(i)==1 & codif.binmsg(i+1)==1) a=codif.Acanal;
        end
        for j=1:n
          canalx(n*(i-1)/2+j)=(i-1)*codif.tb+(2*codif.tb/n)*j;
          canaly(n*(i-1)/2+j)=a-codif.Acanal/2;
        end
      end
      codif.binmsg=codif.binmsg(1:codif.b);
    % ASK
    case menu.ask
      i=1;
      % Calcula la integral de un simbolo '1'
      sum=0;
      for j=1:n
        t=(i-1)*codif.tb+(codif.tb/n)*j;
        sum=sum+abs(1*(codif.Acanal/2)*sin(2*pi*codif.Fp*t));
      end
      codif.ASKth=sum/2;
      for i=1:codif.b
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          canaly(n*(i-1)+j)=codif.binmsg(i)*(codif.Acanal/2)*sin(2*pi*codif.Fp*canalx(n*(i-1)+j));
        end
      end
    % FSK
    case menu.fsk
      %fase_inicial=0;
      for i=1:codif.b
        if (codif.binmsg(i)==0) v=-1;
        else v=1;
        end
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          canaly(n*(i-1)+j)=(codif.Acanal/2)*sin(2*pi*(codif.Fp+v*codif.dF)*canalx(n*(i-1)+j));
          % Con el calculo siguiente se evitan los cambios abruptos de
          % fase, pero habria que modificar tambien el algoritmo de
          % decodificacion pues la se�al no es reconocida debidamente.
          % Notese que hay que inicializar y mantener la variable
          % fase_inicial
          %t=j*codif.tb/n;
          %canalx(n*(i-1)+j)=(i-1)*codif.tb+t;
          %fase=fase_inicial+2*pi*(codif.Fp+v*codif.dF)*t;
          %canaly(n*(i-1)+j)=(codif.Acanal/2)*sin(fase);
        end
        %fase_inicial=fase;
      end
    % PSK
    case menu.psk
      f=0;
      i=1;
      % Numero de muestras a tomar
      codif.nm=(codif.b+1)*codif.tb*codif.fm;
      % Muestras por bit
      n=floor(codif.nm/(codif.b+1));
      % Calcula la diferencia de cuadrados de una diferencia de fase pi
      sum=0; sum2=0;
      di=floor((codif.fm/codif.Fp)*floor(codif.tb*codif.Fp));
      for j=1:di
        t=(i-1)*codif.tb+(codif.tb/n)*j;
        sum=sum+((codif.Acanal/2)*sin(2*pi*codif.Fp*t)-(codif.Acanal/2)*sin(2*pi*codif.Fp*t+codif.Pp))^2;
      end
      codif.PSKth=sum/2;
      % Codifica un 0 como inicio de la transmision
      for j=1:n
        canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
        canaly(n*(i-1)+j)=(codif.Acanal/2)*sin(2*pi*codif.Fp*canalx(n*(i-1)+j)+f*codif.Pp);
      end
      % Codifica los bits del mensaje
      for i=2:codif.b+1
        if (codif.binmsg(i-1)==0) f=f;
        else if (f==0) f=1; else f=0; end;
        end
        for j=1:n
          canalx(n*(i-1)+j)=(i-1)*codif.tb+(codif.tb/n)*j;
          canaly(n*(i-1)+j)=(codif.Acanal/2)*sin(2*pi*codif.Fp*canalx(n*(i-1)+j)+f*codif.Pp);
        end
      end

    % QPSK
    case menu.qpsk
      f=0;
      i=-1;
      % Numero de bits a codificar
      l=codif.b;
      if (mod(l,2)==1) l=l+1; codif.binmsg(l)=0; end
      codif.xmax=codif.tb*(l+2);

      % Numero de muestras a tomar
      codif.nm=l*codif.tb*codif.fm;
      % Muestras por bit
      n=floor(codif.nm/(l/2));

      % Calcula las diferencias de cuadrados de las diferencias de fase de 3*pi/4 y de pi/4
      summax=0; summin=0;
      di=floor((codif.fm/codif.Fp)*floor(2*codif.tb*codif.Fp));
      for j=1:di
        t=(i+1)*codif.tb+(2*codif.tb/n)*j;
        summax=summax+((codif.Acanal/2)*sin(2*pi*codif.Fp*t)-(codif.Acanal/2)*sin(2*pi*codif.Fp*t+3*pi/4))^2;
        summin=summin+((codif.Acanal/2)*sin(2*pi*codif.Fp*t)-(codif.Acanal/2)*sin(2*pi*codif.Fp*t+pi/4))^2;
      end
      codif.PSKth=(summax-summin)/2+summin;
      % Codifica una fase 0 como inicio de la transmision
      for j=1:n
        canalx(n*(i+1)/2+j)=(i+1)*codif.tb+(2*codif.tb/n)*j;
        canaly(n*(i+1)/2+j)=(codif.Acanal/2)*sin(2*pi*codif.Fp*canalx(n*(i+1)/2+j)+f*pi/4);
      end

      % Codifica los bits del mensaje
      for i=1:2:codif.b
        if (codif.binmsg(i)==0 & codif.binmsg(i+1)==0) f=f+1;
        elseif (codif.binmsg(i)==0 & codif.binmsg(i+1)==1) f=f+3;
        elseif (codif.binmsg(i)==1 & codif.binmsg(i+1)==0) f=f+5;
        elseif (codif.binmsg(i)==1 & codif.binmsg(i+1)==1) f=f+7;
        end
	f=mod(f,8);
        for j=1:n
          canalx(n*(i+1)/2+j)=(i+1)*codif.tb+(2*codif.tb/n)*j;
          canaly(n*(i+1)/2+j)=(codif.Acanal/2)*sin(2*pi*codif.Fp*canalx(n*(i+1)/2+j)+f*pi/4);
        end
      end

    % Codificacion desconocida
    otherwise
        return
  end


% Esta funcion genera dos arrays con la senyal correspondiente a la codificacion
%   indicada para la velocidad y el mensaje indicados.
% --------------------------------------------------------------------
function [rcbinmsg]=decodif_canal()
  global codif menu;
  % Muestras por bit
  n=floor(codif.nm/codif.b);
  
  switch codif.cod
    % NRZ    
    case menu.nrz
      for i=1:codif.b
        if (codif.receivedy(n*(i-1)+floor(n/2))>0) rcbinmsg(i)=1;
        elseif (codif.receivedy(n*(i-1)+floor(n/2))<0) rcbinmsg(i)=0;
        else rcbinmsg(i)=2;
        end
      end
    % TTL    
    case menu.ttl
      for i=1:codif.b
        if (codif.receivedy(n*(i-1)+floor(n/2))>codif.Acanal*3.5/5) rcbinmsg(i)=1;
        elseif (codif.receivedy(n*(i-1)+floor(n/2))<codif.Acanal*1.5/5) rcbinmsg(i)=0;
        else rcbinmsg(i)=2;
        end
      end
    % Manchester
    case menu.bifase
      for i=1:codif.b
        if ((codif.receivedy(n*(i-1)+floor(n/4))<0) & (codif.receivedy(n*(i-1)+floor(3*n/4))>=0)) rcbinmsg(i)=1;
        elseif ((codif.receivedy(n*(i-1)+floor(n/4))>=0) & (codif.receivedy(n*(i-1)+floor(3*n/4))<0)) rcbinmsg(i)=0;
        else rcbinmsg(i)=2;
        end
      end
    % Manchester diferencial
    case menu.bifasedif
      for i=1:codif.b
        if ((codif.receivedy(n*i+floor(n/4))<0) & (codif.receivedy(n*(i-1)+floor(3*n/4))>0)) rcbinmsg(i)=0;
        elseif ((codif.receivedy(n*i+floor(n/4))>0) & (codif.receivedy(n*(i-1)+floor(3*n/4))<0)) rcbinmsg(i)=0;
        elseif ((codif.receivedy(n*i+floor(n/4))>0) & (codif.receivedy(n*(i-1)+floor(3*n/4))>0)) rcbinmsg(i)=1;
        elseif ((codif.receivedy(n*i+floor(n/4))<0) & (codif.receivedy(n*(i-1)+floor(3*n/4))<0)) rcbinmsg(i)=1;
        else rcbinmsg(i)=2;
        end
      end
    % Bipolar
    case menu.bipolar
      s=1;     
      for i=1:codif.b
        if (abs(codif.receivedy(n*(i-1)+floor(n/2)))<codif.Acanal/4) rcbinmsg(i)=0;
        elseif (s*codif.receivedy(n*(i-1)+floor(n/2))>codif.Acanal/4) rcbinmsg(i)=1; s=-s;
        else rcbinmsg(i)=2;
        end
      end

    % B8ZS
    case menu.b8zs
      for i=1:codif.b
        if (abs(codif.receivedy(n*(i-1)+floor(n/2)))<codif.Acanal/4) m(i)=0;
        elseif (codif.receivedy(n*(i-1)+floor(n/2))>codif.Acanal/4) m(i)=1;
        elseif (codif.receivedy(n*(i-1)+floor(n/2))<-codif.Acanal/4) m(i)=-1;
        end
      end
      i=1; s=1; z=0;
      while (i<=codif.b)
          if (z<3)
              if (m(i)==0) rcbinmsg(i)=0; z=z+1;
              elseif (m(i)==s) rcbinmsg(i)=1; s=-s; z=0;
              else rcbinmsg(i)=2;
              end
              i=i+1;
          else
              if (m(i)==s) rcbinmsg(i)=1; s=-s; z=0; i=i+1;
              elseif (i+4<=codif.b & m(i)==-s & m(i+1)==s & m(i+2)==0 & m(i+3)==s & m(i+4)==-s)
                  rcbinmsg(i:i+4)=0; z=0; i=i+5;
              elseif (z>=7 & m(i)==0) rcbinmsg(i)=2; z=z+1; i=i+1;
              elseif (m(i)==0) rcbinmsg(i)=0; z=z+1; i=i+1;
              else rcbinmsg(i)=2; z=0; i=i+1;
              end
          end
      end

    % Multinivel    
    case menu.multinivel
      % Numero de muestras a tomar
      codif.nm=codif.b*codif.tb*codif.fm;
      % Muestras por bit
      n=floor(codif.nm/(codif.b/2));
      l=codif.b;
      if (mod(l,2)==1) l=l+1; end
      for i=1:2:l
        if     (codif.receivedy(n*(i-1)/2+floor(n/2))+codif.Acanal/2<codif.Acanal*1/6) rcbinmsg(i)=0; rcbinmsg(i+1)=0;
        elseif (codif.receivedy(n*(i-1)/2+floor(n/2))+codif.Acanal/2<codif.Acanal*3/6) rcbinmsg(i)=0; rcbinmsg(i+1)=1;
        elseif (codif.receivedy(n*(i-1)/2+floor(n/2))+codif.Acanal/2<codif.Acanal*5/6) rcbinmsg(i)=1; rcbinmsg(i+1)=0;
        else rcbinmsg(i)=1; rcbinmsg(i+1)=1;
        end
      end
      rcbinmsg=rcbinmsg(1:codif.b);

    % ASK
    case menu.ask
      for i=1:codif.b
        sum=0;
        for j=1:n
	  sum=sum+abs(codif.receivedy(n*(i-1)+j));
        end
        if (sum>codif.ASKth) rcbinmsg(i)=1;
        else rcbinmsg(i)=0;
        end
      end


    % FSK
    case menu.fsk
      % Separa los canales mediante filtrado
      l1=codif.low; h1=codif.Fp;
      l2=codif.Fp; h2=codif.high;
      espectro=fft(codif.receivedy);
      ec1=recv(espectro,codif.fm,l1,h1);
      ec2=recv(espectro,codif.fm,l2,h2);
      c1=ifft(ec1);
      c2=ifft(ec2);
      for i=1:codif.b
        sum1=0;
        sum2=0;
        for j=1:n
	  sum1=sum1+abs(c1(n*(i-1)+j));
	  sum2=sum2+abs(c2(n*(i-1)+j));
        end
%        m=sprintf('i=%2d: sum1=%10.5f sum2=%10.5f',i,sum1,sum2);
%        disp(m);
        if (sum1>sum2) rcbinmsg(i)=0;
        else rcbinmsg(i)=1;
        end
      end

    % PSK
    case menu.psk
      n=floor(codif.nm/(codif.b+1));
%      m=sprintf('PSKth=%10.5f',codif.PSKth);
%      disp(m);
      % Distancia entre periodos similares de dos simbolos (en muestras)
      di=floor((codif.fm/codif.Fp)*floor(codif.tb*codif.Fp));
      % El simbolo inicial es un 0, se calcula la diferencia desde el segundo simbolo
      for i=2:codif.b+1
        sum=0;
        for j=1:di
     	  sum=sum+(codif.receivedy(n*(i-1)+j)-codif.receivedy(n*(i-1)+j-di))^2;
        end
%        m=sprintf('i=%d: d=%10.5f',i,sum);
%        disp(m);
        if (sum>codif.PSKth) rcbinmsg(i-1)=1;
        else rcbinmsg(i-1)=0;
        end
      end

    % QPSK
    case menu.qpsk
      % Numero de bits a codificar
      l=codif.b;
      if (mod(l,2)==1) l=l+1; codif.binmsg(l)=0; end
      codif.xmax=codif.tb*(l+2);

      % Numero de muestras a tomar
      codif.nm=l*codif.tb*codif.fm;
      % Muestras por bit
      n=floor(codif.nm/(l/2));

      % Distancia entre periodos similares de dos simbolos (en muestras)
      di=floor((codif.fm/codif.Fp)*floor(2*codif.tb*codif.Fp));
      % El simbolo inicial es un 0, se calcula la diferencia desde el segundo simbolo
      s=1;
      for i=1:2:l
        sum2=0; sum=0;
        for j=1:di
     	  sum2=sum2+(codif.receivedy(n*(i+1)/2+j)-codif.receivedy(n*(i+1)/2+j-di))^2;
     	  sum=sum+(codif.receivedy(n*(i+1)/2+j)-codif.receivedy(n*(i+1)/2+j-di));
        end
%        m=sprintf('i=%d: d2=%10.5f d=%10.5f',i,sum2,sum);
%        disp(m);
        if (sum2<codif.PSKth & s*sum<0) rcbinmsg(i)=0; rcbinmsg(i+1)=0;
        elseif (sum2>codif.PSKth & s*sum<0) rcbinmsg(i)=0; rcbinmsg(i+1)=1;
        elseif (sum2>codif.PSKth & s*sum>0) rcbinmsg(i)=1; rcbinmsg(i+1)=0;
        elseif (sum2<codif.PSKth & s*sum>0) rcbinmsg(i)=1; rcbinmsg(i+1)=1;
        end
      end
      rcbinmsg=rcbinmsg(1:codif.b);

    otherwise
        return
  end

% --------------------------------------------------------------------
% Carga imagen y la visualiza
function setlogo(ax)
  set(gcf,'CurrentAxes',ax);
  %load('logo');
  %imshow(logoimg,logocmap);
